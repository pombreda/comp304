
import SudokuVisitor

class SudokuSaver(SudokuVisitor.SudokuVisitor):
    def __init__(self, file):
        super(SudokuSaver, self).__init__()
        self.file = file
        pass
        
    def visitBoard(self, board):
        for value in board.state:
        	if board.state[value] == None:
        		self.file.write("0")
        	else:
        		self.file.write(str(board.state[value]))
        	self.file.write(" ")
        
    
