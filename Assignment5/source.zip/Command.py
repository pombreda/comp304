

class Command(object):
    def do(self):
        pass
        
    def undo(self):
        pass
        
    def __init__(self):
        pass
    
