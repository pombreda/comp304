
import GridWindow

class RowWindow(GridWindow.GridWindow):
    def __init__(self, master, controller, rowOffset, colOffset):
        super(RowWindow, self).__init__(master, controller, 1, 9, rowOffset, colOffset)
        pass
        
    
