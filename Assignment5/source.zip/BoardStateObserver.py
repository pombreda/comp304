

class BoardStateObserver(object):
    def boardStateChanged(self, board):
        pass
        
    def __init__(self):
        pass
    
