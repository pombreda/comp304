
import GridWindow

class BlockWindow(GridWindow.GridWindow):
    def __init__(self, master, controller, rowOffset, colOffset):
        super(BlockWindow, self).__init__(master, controller, 3, 3, rowOffset, colOffset)
        pass
        
    
