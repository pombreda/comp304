

class SudokuVisitor(object):
    def visitBoard(self, board):
        pass
        
    def __init__(self):
        pass
    
